# Taj's Cheats

Cheat utilities powered by Taj's Core. Adds a Cheats tab in the Core settings menu
for quick currency and attribute adjustments.

Requires TajemnikTV-Core 1.0.1+.
