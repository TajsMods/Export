# Taj's Mods: Command Palette

[![Ask DeepWiki](https://deepwiki.com/badge.svg)](https://deepwiki.com/TajsMods/CommandPalette)

UI module that provides the in-game command palette. Depends on `TajemnikTV-Core` for the command registry and registers `core.command_palette` for palette settings/state.
