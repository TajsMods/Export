# Command Palette

UI module that provides the in-game command palette. Depends on `TajemnikTV-Core` for the command registry and registers `core.command_palette` for palette settings/state.
