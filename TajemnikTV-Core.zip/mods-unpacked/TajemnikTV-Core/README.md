# Taj's Core Framework

## How to use

Currently available docs are outdated and possibly will stay that way, until all the Core features are added and complete (which is never lol?)
Website Docs: https://tajsmods.github.io/docs/core/main/ (Possibly worst source of information, these are there mostly as a placeholder)
Deepwiki: https://deepwiki.com/TajsMods/Core (Can be updated every 7 days)

## Credits

Free icons from [Streamline](https://streamlinehq.com/free-icons)
