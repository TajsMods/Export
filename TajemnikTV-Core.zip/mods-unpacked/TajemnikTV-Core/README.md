# Taj's Core Framework

## Credits

Free icons from [Streamline](https://streamlinehq.com/free-icons)
