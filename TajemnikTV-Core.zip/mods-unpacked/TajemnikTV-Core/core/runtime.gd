class_name TajsCoreRuntime
extends Node

var CORE_VERSION: String = "0.0.0"
const API_LEVEL := 1
const META_KEY := "TajsCore"

var logger: Variant
var settings: Variant
var migrations: Variant
var event_bus: Variant
var command_registry: Variant
var commands: Variant
var context_menu: Variant
var context_menus: Variant
var command_palette: Variant
var command_palette_controller: Variant
var command_palette_overlay: Variant
var keybinds: Variant
var patches: Variant
var diagnostics: Variant
var module_registry: Variant
var modules: Variant
var workshop_sync: Variant
var ui_manager: Variant
var node_registry: Variant
var nodes: Variant
var util: Variant

var features: Variant
var assets: Variant
var localization: Variant
var theme_manager: Variant
var icon_registry: Variant
var window_scenes: Variant
var file_variations: Variant
var window_menus: Variant
var tree_registry: Variant
var trees: Variant
var hook_manager: Variant
var upgrade_caps: Variant
var undo_manager: Variant
var node_finder: Variant
var safe_ops: Variant
var calculations: Variant
var economy_helpers: Variant
var node_limit_helpers: Variant
var resource_helpers: Variant
var connectivity_helpers: Variant
var boot_screen: Variant
var desktop_layers: Variant

var _version_util: Variant
var _extended_globals: Dictionary = {}
var _base_dir: String = ""

# Runtime patching state for scripts with class_name (can't use install_script_extension)
var _desktop_patched := false
var _desktop_patch_failed := false
var _loading_save_sanitized := false
var _loading_save_sanitize_attempts := 0
var _scene_text_cache: Dictionary = {}

func _init() -> void:
    bootstrap()

func _ready() -> void:
    if node_registry != null:
        node_registry.setup_signals()
    _sanitize_loading_save_if_needed()

func _process(_delta: float) -> void:
    _sanitize_loading_save_if_needed()
    # Runtime patching for Desktop (has class_name, can't use install_script_extension)
    if not _desktop_patched and not _desktop_patch_failed:
        if is_instance_valid(Globals.desktop) and patches != null:
            var desktop_ext := _base_dir.path_join("extensions/desktop.gd")
            var result: bool = patches.patch_desktop(desktop_ext)
            if result:
                _desktop_patched = true
            else:
                _desktop_patch_failed = true

func _sanitize_loading_save_if_needed() -> void:
    if _loading_save_sanitized:
        return
    _loading_save_sanitize_attempts += 1
    var data_autoload: Variant = _get_autoload("Data")
    if data_autoload == null:
        if _loading_save_sanitize_attempts <= 3:
            logd("core", "Save sanitize: Data autoload not available yet (attempt %d)." % _loading_save_sanitize_attempts)
        return
    if not data_autoload.has_method("get"):
        return
    var loading: Variant = data_autoload.get("loading")
    if not (loading is Dictionary):
        if _loading_save_sanitize_attempts <= 3:
            logd("core", "Save sanitize: Data.loading not ready yet (attempt %d)." % _loading_save_sanitize_attempts)
        return
    if loading.is_empty():
        if _loading_save_sanitize_attempts <= 3:
            logd("core", "Save sanitize: Data.loading is empty (attempt %d)." % _loading_save_sanitize_attempts)
        return
    if not loading.has("desktop_data"):
        _loading_save_sanitized = true
        return
    var desktop_data: Variant = loading.get("desktop_data", {})
    if not (desktop_data is Dictionary):
        _loading_save_sanitized = true
        return
    var windows_data: Variant = desktop_data.get("windows", [])
    if not (windows_data is Array):
        _loading_save_sanitized = true
        return

    var windows_defs: Variant = data_autoload.get("windows")
    logi("core", "Save sanitize: processing %d desktop windows." % windows_data.size())
    var filtered: Array = []
    var dropped_count := 0
    for entry_var: Variant in windows_data:
        if not (entry_var is Dictionary):
            continue
        var entry: Dictionary = entry_var
        var filename := str(entry.get("filename", ""))
        var window_id := str(entry.get("window", ""))
        var window_name := str(entry.get("name", ""))
        var original_filename := filename

        # Migrate legacy script filenames to scene filenames before Desktop loads windows.
        if filename.ends_with(".gd"):
            var mapped_scene := ""
            if windows_defs is Dictionary and window_id != "" and windows_defs.has(window_id):
                var def: Variant = windows_defs[window_id]
                if def is Dictionary:
                    mapped_scene = str(def.get("scene", ""))
            if mapped_scene != "":
                filename = mapped_scene + ".tscn"
            else:
                filename = filename.trim_suffix(".gd") + ".tscn"
            entry["filename"] = filename
            logw("core", "Save sanitize: converted legacy script filename '%s' -> '%s' (window '%s', id '%s')." % [original_filename, filename, window_name, window_id])

        # Guard broken legacy entries known to crash on 4.6.2 load paths.
        var normalized := filename.to_lower()
        if normalized == "window_encompressor" or normalized == "window_encompressor.tscn":
            dropped_count += 1
            logw("core", "Save sanitize: dropped legacy window '%s' filename '%s'." % [window_name, filename])
            continue
        if normalized == "window_machine_producer.gd" or normalized == "window_machine_producer":
            dropped_count += 1
            logw("core", "Save sanitize: dropped invalid producer script entry '%s' (name '%s')." % [filename, window_name])
            continue
        if window_name.to_lower() == "miner0":
            dropped_count += 1
            logw("core", "Save sanitize: quarantined crashing entry '%s' (window '%s', filename '%s')." % [window_name, window_id, filename])
            continue

        # Structural guard: drop save entries incompatible with target scene layout.
        var scene_path := "res://scenes/windows/" + filename
        if not ResourceLoader.exists(scene_path):
            dropped_count += 1
            logw("core", "Save sanitize: dropped missing scene '%s' (window '%s', id '%s')." % [scene_path, window_name, window_id])
            continue
        if entry.has("progress") and not _scene_has_node_name(scene_path, "Process"):
            dropped_count += 1
            logw("core", "Save sanitize: dropped entry needing Process node but missing in scene '%s' (window '%s', id '%s')." % [filename, window_name, window_id])
            continue
        if entry.has("level") and not _scene_has_node_name(scene_path, "Component"):
            dropped_count += 1
            logw("core", "Save sanitize: dropped entry needing Component node but missing in scene '%s' (window '%s', id '%s')." % [filename, window_name, window_id])
            continue

        filtered.append(entry)

    desktop_data["windows"] = filtered
    loading["desktop_data"] = desktop_data
    data_autoload.set("loading", loading)
    _loading_save_sanitized = true
    logi("core", "Save sanitize complete: kept %d, dropped %d windows." % [filtered.size(), dropped_count])

func _scene_has_node_name(scene_path: String, node_name: String) -> bool:
    if scene_path == "" or node_name == "":
        return false
    var text: String = _scene_text_cache.get(scene_path, "")
    if text == "":
        if not FileAccess.file_exists(scene_path):
            return false
        text = FileAccess.get_file_as_string(scene_path)
        _scene_text_cache[scene_path] = text
    return text.contains("name=\"%s\"" % node_name)

func bootstrap() -> void:
    if Engine.has_meta(META_KEY) and Engine.get_meta(META_KEY) != self:
        _log_fallback("Core already registered, skipping bootstrap.")
        return
    Engine.set_meta(META_KEY, self )
    var base_dir: String = get_script().resource_path.get_base_dir()
    _base_dir = base_dir
    CORE_VERSION = _read_version_from_manifest(base_dir.get_base_dir().path_join("manifest.json"))
    # Init order: version -> logger -> settings -> migrations -> event_bus -> commands -> keybinds -> patches -> diagnostics -> module_registry -> core.ready
    _version_util = _load_script(base_dir.path_join("version.gd"))
    var logger_script: Variant = _load_script(base_dir.path_join("logger.gd"))
    if logger_script != null:
        logger = logger_script.new()

    var settings_script: Variant = _load_script(base_dir.path_join("settings.gd"))
    if settings_script != null:
        settings = settings_script.new(logger)
        _register_core_schema()
        _apply_logger_settings()

    var features_script: Variant = _load_script(base_dir.path_join("features.gd"))
    if features_script != null and settings != null:
        features = features_script.new()
        features.setup(settings)

    var migrations_script: Variant = _load_script(base_dir.path_join("migrations.gd"))
    if migrations_script != null and settings != null:
        migrations = migrations_script.new(settings, logger, _version_util)
        _register_core_migrations()
        migrations.run_pending("core")

    var event_bus_script: Variant = _load_script(base_dir.path_join("event_bus.gd"))
    if event_bus_script != null:
        event_bus = event_bus_script.new(logger)
        _bridge_settings_events()
        _bind_command_palette_events()

    var command_registry_script: Variant = _load_script(base_dir.path_join("commands/command_registry.gd"))
    if command_registry_script != null:
        command_registry = command_registry_script.new(logger, event_bus)
        commands = command_registry

    var context_menu_script: Variant = _load_script(base_dir.path_join("context_menu/context_menu_service.gd"))
    if context_menu_script != null:
        context_menu = context_menu_script.new(logger, event_bus)
        context_menus = context_menu

    var assets_script: Variant = _load_script(base_dir.path_join("assets.gd"))
    if assets_script != null:
        assets = assets_script.new()
    var icon_registry_script: Variant = _load_script(base_dir.path_join("icon_registry.gd"))
    if icon_registry_script != null:
        icon_registry = icon_registry_script.new(assets)

    var localization_script: Variant = _load_script(base_dir.path_join("localization.gd"))
    if localization_script != null:
        localization = localization_script.new()

    var theme_script: Variant = _load_script(base_dir.path_join("theme_manager.gd"))
    if theme_script != null:
        theme_manager = theme_script.new()
        # Apply tooltip styling to match in-game UI design
        if theme_manager.has_method("apply_tooltip_styling"):
            call_deferred("_apply_tooltip_styling")

    var window_scenes_script: Variant = _load_script(base_dir.path_join("window_scenes.gd"))
    if window_scenes_script != null:
        window_scenes = window_scenes_script.new(logger)

    var file_variations_script: Variant = _load_script(base_dir.path_join("file_variations.gd"))
    if file_variations_script != null:
        file_variations = file_variations_script.new(settings, logger)

    var window_menus_script: Variant = _load_script(base_dir.path_join("window_menus.gd"))
    if window_menus_script != null:
        window_menus = window_menus_script.new()

    var tree_script: Variant = _load_script(base_dir.path_join("tree_registry.gd"))
    if tree_script != null:
        tree_registry = tree_script.new()
        trees = tree_registry

    var keybinds_script: Variant = _load_script(base_dir.path_join("keybinds.gd"))
    if keybinds_script != null:
        keybinds = keybinds_script.new()
        add_child(keybinds)
        keybinds.setup(settings, logger, event_bus)

    var patches_script: Variant = _load_script(base_dir.path_join("patches.gd"))
    if patches_script != null:
        patches = patches_script.new(logger)

    var util_script: Variant = _load_script(base_dir.path_join("util.gd"))
    if util_script != null:
        util = util_script.new()

    var calculations_script: Variant = _load_script(base_dir.path_join("util/calculations.gd"))
    if calculations_script != null:
        calculations = calculations_script.new()

    var economy_helpers_script: Variant = _load_script(base_dir.path_join("util/economy_helpers.gd"))
    if economy_helpers_script != null:
        economy_helpers = economy_helpers_script.new()

    var node_limit_helpers_script: Variant = _load_script(base_dir.path_join("util/node_limit_helpers.gd"))
    if node_limit_helpers_script != null:
        node_limit_helpers = node_limit_helpers_script.new()

    var node_finder_script: Variant = _load_script(base_dir.path_join("util/node_finder.gd"))
    if node_finder_script != null:
        node_finder = node_finder_script.new()

    var resource_helpers_script: Variant = _load_script(base_dir.path_join("util/resource_helpers.gd"))
    if resource_helpers_script != null:
        resource_helpers = resource_helpers_script.new()

    var connectivity_script: Variant = _load_script(base_dir.path_join("util/connectivity_helpers.gd"))
    if connectivity_script != null:
        connectivity_helpers = connectivity_script.new()

    var safe_ops_script: Variant = _load_script(base_dir.path_join("util/safe_ops.gd"))
    if safe_ops_script != null:
        safe_ops = safe_ops_script.new()

    var undo_script: Variant = _load_script(base_dir.path_join("util/undo_manager.gd"))
    if undo_script != null:
        undo_manager = undo_script.new(logger)
        undo_manager.setup()
        _register_undo_keybinds()

    var upgrade_caps_script: Variant = _load_script(base_dir.path_join("mechanics/upgrade_caps.gd"))
    if upgrade_caps_script != null:
        upgrade_caps = upgrade_caps_script.new(logger)

    var node_registry_script: Variant = _load_script(base_dir.path_join("nodes/node_registry.gd"))
    if node_registry_script != null:
        node_registry = node_registry_script.new(logger, event_bus, patches)
        nodes = node_registry


    var diagnostics_script: Variant = _load_script(base_dir.path_join("diagnostics.gd"))
    if diagnostics_script != null:
        diagnostics = diagnostics_script.new(self , logger)

    var registry_script: Variant = _load_script(base_dir.path_join("module_registry.gd"))
    if registry_script != null:
        module_registry = registry_script.new(self , logger, event_bus)
        modules = module_registry

    var hooks_script: Variant = _load_script(base_dir.path_join("hooks/hook_manager.gd"))
    if hooks_script != null:
        hook_manager = hooks_script.new()
        hook_manager.name = "CoreHooks"
        hook_manager.setup(self )
        add_child(hook_manager)

    var desktop_layers_script: Variant = _load_script(base_dir.path_join("desktop_layers.gd"))
    if desktop_layers_script != null:
        desktop_layers = desktop_layers_script.new(logger, event_bus)
        desktop_layers.setup()

    _install_modloader_extensions(base_dir)

    if event_bus != null:
        event_bus.emit("core.ready", {"version": CORE_VERSION, "api_level": API_LEVEL}, true)
    if logger != null:
        logger.info("core", "Taj's Core ready (%s)." % CORE_VERSION)
    _init_boot_screen(base_dir)
    _init_optional_services(base_dir)

func get_version() -> String:
    return CORE_VERSION

func get_api_level() -> int:
    return API_LEVEL

func compare_versions(a: String, b: String) -> int:
    if _version_util != null:
        return _version_util.compare_versions(a, b)
    return 0

func require(min_version: String) -> bool:
    if min_version == "":
        return true
    return compare_versions(CORE_VERSION, min_version) >= 0

func register_module(meta: Dictionary) -> bool:
    if module_registry == null:
        return false
    return module_registry.register_module(meta)

func extend_globals(property: String, value: Variant) -> void:
    if property == "":
        return
    _extended_globals[property] = value

func get_extended_global(property: String, default_value: Variant = null) -> Variant:
    if _extended_globals.has(property):
        return _extended_globals[property]
    return default_value

func get_upgrade_cap(upgrade_id: String) -> int:
    if upgrade_caps != null:
        return upgrade_caps.get_effective_cap(upgrade_id)
    if Data.upgrades.has(upgrade_id):
        var limit := int(Data.upgrades[upgrade_id].limit)
        return -1 if limit == 0 else limit
    return -1

func register_extended_cap(upgrade_id: String, config: Dictionary) -> void:
    if upgrade_caps != null:
        upgrade_caps.register_extended_cap(upgrade_id, config)

func logd(module_id: String, message: String) -> void:
    if logger != null:
        logger.debug(module_id, message)

func logi(module_id: String, message: String) -> void:
    if logger != null:
        logger.info(module_id, message)

func logw(module_id: String, message: String) -> void:
    if logger != null:
        logger.warn(module_id, message)

func loge(module_id: String, message: String) -> void:
    if logger != null:
        logger.error(module_id, message)

func notify(icon: String, message: String) -> void:
    if ui_manager != null and ui_manager.has_method("show_notification"):
        ui_manager.show_notification(icon, message)
        return
    var signals: Variant = _get_autoload("Signals")
    if signals != null and signals.has_signal("notify"):
        var _ignored: Variant = signals.emit_signal("notify", icon, message)

func play_sound(sound_id: String) -> void:
    var sound: Variant = _get_autoload("Sound")
    if sound != null and sound.has_method("play"):
        sound.play(sound_id)

func copy_to_clipboard(text: String) -> void:
    DisplayServer.clipboard_set(text)

func register_settings_tab(mod_id: String, display_name: String, icon_path: String = "") -> VBoxContainer:
    """Registers a settings tab for a mod. Returns null if UI not ready yet."""
    if ui_manager == null:
        return null
    return ui_manager.register_mod_settings_tab(mod_id, display_name, icon_path)

func get_settings_tab(mod_id: String) -> VBoxContainer:
    """Returns an existing settings tab container for a mod."""
    if ui_manager == null:
        return null
    return ui_manager.get_mod_settings_tab(mod_id)

func get_game_theme() -> Theme:
    """Returns the game's main.tres theme for consistent font and styling."""
    if theme_manager != null:
        return theme_manager.get_game_theme()
    # Fallback if theme_manager not ready
    if ResourceLoader.exists("res://themes/main.tres"):
        return load("res://themes/main.tres")
    return null

func get_icon_registry() -> Variant: # Returns TajsCoreIconRegistry (Variant to avoid parse errors)
    return icon_registry

static func instance() -> TajsCoreRuntime:
    if Engine.has_meta(META_KEY):
        return Engine.get_meta(META_KEY)
    return null

static func require_core(min_version: String) -> bool:
    var core: Variant = instance()
    if core == null:
        return false
    return core.require(min_version)

func _register_core_schema() -> void:
    var schema := {
        "core.debug": {
            "type": "bool",
            "default": false,
            "description": "Enable debug logging"
        },
        "core.debug_log": {
            "type": "bool",
            "default": false,
            "description": "Deprecated: use core.debug"
        },
        "core.log_to_file": {
            "type": "bool",
            "default": false,
            "description": "Write logs to user://tajs_core.log"
        },
        "core.log_file_path": {
            "type": "string",
            "default": "user://tajs_core.log",
            "description": "Override log file path"
        },
        "core.log_ring_size": {
            "type": "int",
            "default": 200,
            "description": "In-memory log history size"
        },

        "core.workshop.sync_on_startup": {
            "type": "bool",
            "default": true,
            "description": "Check Workshop updates on startup"
        },
        "core.workshop.high_priority": {
            "type": "bool",
            "default": true,
            "description": "Use high priority for Workshop downloads"
        },
        "core.workshop.force_download_all": {
            "type": "bool",
            "default": true,
            "description": "Request downloads for all subscribed items"
        },
        "core.keybinds.overrides": {
            "type": "dict",
            "default": {},
            "description": "Keybind overrides"
        },
        "core.features": {
            "type": "dict",
            "default": {},
            "description": "Feature flag overrides"
        },
        "core.boot_screen_enabled": {
            "type": "bool",
            "default": false,
            "description": "Enable custom boot screen"
        },
        "core.undo_enabled": {
            "type": "bool",
            "default": true,
            "label": "Enable Undo/Redo",
            "description": "Enable undo/redo functionality (Ctrl+Z / Ctrl+Y).",
            "category": "Editing"
        }
    }
    settings.register_schema("core", schema)

func _apply_logger_settings() -> void:
    var debug_enabled: bool = settings.get_bool("core.debug", settings.get_bool("core.debug_log", false))
    logger.set_debug_enabled(debug_enabled)
    logger.set_ring_size(settings.get_int("core.log_ring_size", 200))
    var file_path: String = settings.get_string("core.log_file_path", "user://tajs_core.log")
    logger.set_file_logging(settings.get_bool("core.log_to_file", false), file_path)

func _load_script(path: String) -> Variant:
    var script: Variant = load(path)
    if script == null:
        _log_fallback("Failed to load script: %s" % path)
    return script

func _read_version_from_manifest(path: String) -> String:
    if not FileAccess.file_exists(path):
        _log_fallback("Manifest not found: %s" % path)
        return "0.0.0"

    var file: Variant = FileAccess.open(path, FileAccess.READ)
    if file == null:
        _log_fallback("Failed to open manifest: %s" % path)
        return "0.0.0"

    var content: Variant = file.get_as_text()
    var json: Variant = JSON.new()
    var error: Variant = json.parse(content)
    if error == OK:
        var data: Variant = json.data
        if data is Dictionary and data.has("version_number"):
            return data["version_number"]

    _log_fallback("Failed to parse manifest version: %s" % path)
    return "0.0.0"

func _log_fallback(message: String) -> void:
    if logger != null:
        logger.warn("core", message)
    else:
        print("TajsCore: %s" % message)

func _has_global_class(class_name_str: String) -> bool:
    for entry: Variant in ProjectSettings.get_global_class_list():
        if entry.get("class", "") == class_name_str:
            return true
    return false

func _get_autoload(autoload_name: String) -> Object:
    if Engine.has_singleton(autoload_name):
        return Engine.get_singleton(autoload_name)
    if Engine.get_main_loop() == null:
        return null
    var root: Variant = Engine.get_main_loop().root
    if root == null:
        return null
    return root.get_node_or_null(autoload_name)

func _bridge_settings_events() -> void:
    if settings == null or event_bus == null:
        return
    settings.value_changed.connect(Callable(self , "_on_settings_changed"))

func _bind_command_palette_events() -> void:
    if event_bus == null:
        return
    event_bus.on("command_palette.ready", Callable(self , "_on_command_palette_ready"), self , true)

func _on_settings_changed(key: String, value: Variant, old_value: Variant) -> void:
    if event_bus == null:
        return
    event_bus.emit("settings.changed", {"key": key, "old": old_value, "new": value})

func _on_command_palette_ready(payload: Dictionary) -> void:
    command_palette_controller = payload.get("controller", null)
    command_palette_overlay = payload.get("overlay", null)

func _register_core_migrations() -> void:
    if migrations == null or settings == null:
        return
    migrations.register_migration("core", "1.0.0", func() -> void:
        if settings.get_value("core.debug", null) == null and settings.get_value("core.debug_log", null) != null:
            settings.set_value("core.debug", settings.get_bool("core.debug_log", false))
    )

func _register_undo_keybinds() -> void:
    if keybinds == null or undo_manager == null:
        return

    # Register "Editing" category for undo/redo keybinds
    keybinds.register_keybind_category("core_editing", "Editing", "res://textures/icons/return.png")

    # Undo (Ctrl+Z)
    keybinds.register_action_scoped(
        "TajemnikTV-Core",
        "undo",
        "Undo",
        [keybinds.make_key_event(KEY_Z, true)],
        keybinds.CONTEXT_NO_TEXT,
        Callable(self , "_on_undo"),
        10,
        "core_editing"
    )

    # Redo (Ctrl+Y)
    keybinds.register_action_scoped(
        "TajemnikTV-Core",
        "redo",
        "Redo",
        [keybinds.make_key_event(KEY_Y, true)],
        keybinds.CONTEXT_NO_TEXT,
        Callable(self , "_on_redo"),
        10,
        "core_editing"
    )

    # Redo Alt (Ctrl+Shift+Z)
    keybinds.register_action_scoped(
        "TajemnikTV-Core",
        "redo_alt",
        "Redo (Alt)",
        [keybinds.make_key_event(KEY_Z, true, true)],
        keybinds.CONTEXT_NO_TEXT,
        Callable(self , "_on_redo"),
        10,
        "core_editing"
    )

    if logger != null:
        logger.info("core", "Undo/Redo keybinds registered (Ctrl+Z, Ctrl+Y, Ctrl+Shift+Z)")

func _on_undo() -> void:
    if undo_manager == null:
        return
    if settings != null and not settings.get_bool("core.undo_enabled", true):
        return
    if undo_manager.can_undo():
        undo_manager.undo()

func _on_redo() -> void:
    if undo_manager == null:
        return
    if settings != null and not settings.get_bool("core.undo_enabled", true):
        return
    if undo_manager.can_redo():
        undo_manager.redo()

func _init_optional_services(base_dir: String) -> void:
    if settings == null:
        return
    var workshop_script: Variant = _load_script(base_dir.path_join("workshop_sync.gd"))
    if workshop_script != null:
        workshop_sync = workshop_script.new()
        workshop_sync.name = "WorkshopSync"
        workshop_sync.setup(logger)
        workshop_sync.sync_on_startup = settings.get_bool("core.workshop.sync_on_startup", true)
        workshop_sync.high_priority_downloads = settings.get_bool("core.workshop.high_priority", true)
        workshop_sync.force_download_all = settings.get_bool("core.workshop.force_download_all", true)
        add_child(workshop_sync)
        if workshop_sync.sync_on_startup:
            call_deferred("_start_workshop_sync")

    var ui_manager_script: Variant = _load_script(base_dir.path_join("ui/ui_manager.gd"))
    if ui_manager_script != null:
        ui_manager = ui_manager_script.new()
        ui_manager.name = "CoreUiManager"
        ui_manager.setup(self , workshop_sync)
        add_child(ui_manager)

func _start_workshop_sync() -> void:
    if workshop_sync != null:
        workshop_sync.start_sync()

func _apply_tooltip_styling() -> void:
    if theme_manager != null and theme_manager.has_method("apply_tooltip_styling"):
        theme_manager.apply_tooltip_styling()

func _init_boot_screen(base_dir: String) -> void:
    var boot_screen_script: Variant = _load_script(base_dir.path_join("features/boot_screen_feature.gd"))
    if boot_screen_script != null:
        boot_screen = boot_screen_script.new()
        boot_screen.setup(self )

func _install_modloader_extensions(base_dir: String) -> void:
    if not _has_global_class("ModLoaderMod"):
        return
    # NOTE: Scripts with class_name cannot use install_script_extension() because
    # ModLoader's take_over_path() creates a conflict. These are handled specially:
    # - desktop.gd (class_name Desktop) - uses runtime patching in _process()
    # - window_container.gd (class_name WindowContainer) - not yet reimplemented
    # See _process() for desktop runtime patching logic.
    var paths := [
        base_dir.path_join("extensions/data.gd"),
        base_dir.path_join("extensions/connectors.gd"),
        base_dir.path_join("extensions/windows_menu.gd"),
        base_dir.path_join("extensions/window_dragger.gd"),
        base_dir.path_join("extensions/hud.gd"),
        base_dir.path_join("extensions/main.gd"),
        base_dir.path_join("extensions/utils.gd")
    ]
    for path: Variant in paths:
        ModLoaderMod.install_script_extension(path)
