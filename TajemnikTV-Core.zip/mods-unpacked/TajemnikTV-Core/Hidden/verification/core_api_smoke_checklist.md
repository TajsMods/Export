# Core API Smoke Checklist

Use Core diagnostics self-test in-game (Settings -> Core -> Diagnostics -> Run Self-Test).

It now validates:
- invalid namespaced font path rejects with `font_path_not_found`
- `apply_font_to_node(null, ...)` rejects with `node_null`
- `apply_font_to_node(non_control, ...)` rejects with `node_not_control`
- invalid theme profile ID rejects with `profile_id_must_be_namespaced_modid.localid`
- invalid tree mode rejects with `invalid_mode`
- duplicate window tab registration rejects with `duplicate_id`
- cancellable event payload can be cancelled by listener

Manual quick checks:
1. Trigger a window create through Core API and confirm exactly one `core.desktop.window_create_requested` event.
2. Register one manual icon via `register_icon()` and confirm it appears in Icon Browser.
3. Build a theme with a simple `RichTextLabel` mapping and confirm rich text variants use the font.
