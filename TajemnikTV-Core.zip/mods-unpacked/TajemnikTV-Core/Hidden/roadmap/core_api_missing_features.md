# Core API Missing Features Roadmap

## A) Unregister APIs
Missing:
- unregister_window_tab(id)
- unregister_icon(id)
- unregister_font(id)
- unregister_action(id)
- unregister_settings_schema(module_id)
- unregister_translation/path where feasible

Why:
Hot reloads, mod disable/reload, and debugging need cleanup paths.

## B) Owner/Mod Metadata Standardization
Missing:
- parse_namespaced_id(id)
- validate_namespaced_id(id)
- infer_owner_mod_id_from_id(id)
- shared payload fields: owner_mod_id, id, local_id, source

Why:
Runtime wrappers currently duplicate ID logic and can drift.

## C) Result Helper
Missing:
- ok(data := {})
- fail(error, data := {})
- duplicate_id(...)
- unavailable(service_name)

Why:
Wrappers hand-roll `{ok,error}` responses today and can diverge.

## D) Event Constants/Registry
Missing:
A central event list + payload schema map (code or docs-first).
Suggested file: `core/events/event_names.gd`.

Why:
Avoid string-typo bugs and improve discoverability.

## E) Cancellation Semantics
Missing:
A strict contract for cancellable events:
- listeners set `payload["cancelled"] = true`
- source respects cancellation where possible
- only pre/request events are cancellable

Why:
Cancellability exists but conventions are still loose.

## F) Theme Profile Lifecycle
Missing:
- delete_profile(profile_id)
- duplicate_profile(source_id, new_id)
- rename_profile(old_id, new_id)
- list profile metadata
- export/import profile dictionaries (not only `.tres`)

Why:
Theme profile editing exists, lifecycle management is incomplete.

## G) Font Lifecycle and Fallback Policy
Missing:
- unregister_font(font_id)
- set_default_font(font_id)
- configurable fallback policy (fail hard/game fallback/custom fallback)
- list richer font metadata

Why:
Fallback behavior exists but is implicit and not yet configurable.

## H) Runtime API Grouping
Future option (non-breaking): grouped facades in addition to top-level wrappers:
- core.api
- core.fonts
- core.themes
- core.events
- core.ui
- core.windows

Why:
Top-level is discoverable, grouped facades improve long-term organization.

## I) Dev/Debug UI
Missing:
A Core debug panel with:
- event listener counts
- registered fonts
- theme profiles
- window tabs
- icons
- recent Core warnings/errors

Why:
Mod integration debugging is easier with a runtime inspector.

## J) Support Bundle Expansion
Missing:
Include additional API state in diagnostics bundles:
- event listener counts (already present, can be expanded)
- manual icon source entries
- runtime wrapper/service availability
- theme profile metadata
- font warnings/errors/fallback telemetry

Why:
Support bundles should fully reflect Core integration state.
